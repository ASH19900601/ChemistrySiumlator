# 核心源码包（小于 10 MB）

快照提交：7237221264aec7bf613aed17fe275a238718de5d
仓库：https://github.com/ASH19900601/ChemistrySiumlator
分支：claude/trusting-franklin-x92q1i

## 保留内容

- src/：化学引擎、React 界面、9 组引导流程、自由实验台配置、67 组原题的来源索引。
- e2e/、src/**/__tests__/：浏览器和单元测试。
- docs/：开发、使用、覆盖边界、问题修复和下一轮优化分析。
- package.json、package-lock.json、构建配置、Git 属性与项目工作说明。
- tools/：从完整资料包生成原题页面的脚本和固定 Python 依赖版本。

## 为缩小体积未包含

- 约 125 MiB 的原始真题研究 ZIP，以及 dropbox_downloads/ 中的研究报告副本。
- public/past-papers/ 的原卷 PDF、页面图像和 dist/ 生产构建。
- Git 历史、node_modules、Python 虚拟环境、缓存及云环境配置。

因此，这是核心源码交付，不是带齐全部原卷资源的离线成品。67 组来源索引保留，但不能把索引当作已经附带对应原卷。

## 安装与核心验证

建议使用已验证的 Node.js 24.19.0 和 npm 11.9.0，在本目录执行：

    npm ci
    npm test
    npm run typecheck
    npm run dev

化学引擎和引导流程的文字题目、内置评分说明可以用于核心开发；原卷 PDF/图片不会显示，依赖原卷的书面练习无法完整使用。

## 恢复完整题库与生产构建

完整的浏览器检查和 npm run build 会检查或使用原卷文件；本包刻意未附这些大文件，不要把资源缺失误判为引擎单元测试失败，也不要关闭完整性检查。

方法一：从此前的完整项目压缩包复制 dropbox_downloads/ 和 public/past-papers/ 到本目录，再运行 npm run check:papers。

方法二：在联网并已认证 GitHub 的机器取得完整仓库，使用 Git LFS 拉取资料后生成：

    git clone --branch claude/trusting-franklin-x92q1i https://github.com/ASH19900601/ChemistrySiumlator.git full-repository
    cd full-repository
    git lfs install --local
    git lfs pull --include=dropbox_downloads/Chemistry_Qualitative_Practicals_2001-2026.zip
    python3 -m venv ../.chemistry-paper-tools
    . ../.chemistry-paper-tools/bin/activate
    python -m pip install -r tools/requirements.txt
    npm ci
    npm run prepare:papers
    npm run check:papers
    npm run build

恢复完成后也可将生成资料复制回核心源码包。运行浏览器检查需要安装 Chromium；可设置 CHROMIUM_PATH 或执行 npx playwright install chromium。

原题覆盖与未完成项目以 docs/paper-coverage-2023-2026.md 为准。包内 MANIFEST.json 记录内容文件的字节数和 SHA-256。
